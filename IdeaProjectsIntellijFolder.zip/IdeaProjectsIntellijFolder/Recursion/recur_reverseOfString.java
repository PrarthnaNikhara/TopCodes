package com.hello;
//i = index
public class recur_reverseOfString {
    public static void revOfString(String str, int i){
        if(i==0){
            System.out.println(str.charAt(i));
            return;
        }
        System.out.println(str.charAt(i));
        revOfString(str,i-1);
    }
    public static void main(String args[]){
     String   str="abcd";
     revOfString(str,str.length()-1);
    }
}
// O(n)