package com.hello;

public class recursion_sumofnumb {
    public static void sumOFnum(int i,int n,int sum){
       if(i==n){
           sum=sum+i;
           System.out.println(sum);
           return;
       }
        sum=sum+i;
        sumOFnum(i+1,n,sum);
        //try this commented sout also
        //System.out.println(i);
    }
    public static void main(String[] args){
        sumOFnum(1,5,0);
    }
}
