package com.hello;

public class recursion1_printNumbers{
    //for 5 to 1
public static void printNum(int n){
        if(n==0){
        return;
        }
        System.out.println(n);
        printNum(n-1);
        }
    //for 1 to 5
    public static void printNumb(int a){
        if(a==5){
            return;
        }
        System.out.println(a);
        printNumb(a+1);
    }
public static void main(String[]args){
        int n=6;
    printNum(n);
    //for 1 to 5
    System.out.println();
    System.out.println();
    int a=1;
    printNumb(a);
        }
        }

