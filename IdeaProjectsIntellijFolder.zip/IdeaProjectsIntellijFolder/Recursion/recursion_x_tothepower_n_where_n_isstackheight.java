package com.hello;

public class recursion_x_tothepower_n_where_n_isstackheight {
    public static int cal_xPOWERn(int x,int n){
        if(x==0 || n==0){
            return 1;
        }
        int xPOWERnMINUS1=cal_xPOWERn(x,n-1);
        int xPOWERn=xPOWERnMINUS1*x;
        return xPOWERn;
    }
    public static void main(String[] args){
        int x=2,n=5;
        System.out.println( cal_xPOWERn(x,n));
    }
}
// ques explanation
// when the stac of this code will made we will not count the main memory we will count all levels which become 6(not include main memory) in ques given stack height=n  stack height =6 when n=5 the difference is negligible bcoz we take in asymptotic notations thus we can say yes stack height=n is right