package com.hello;

public class recur_callGuest {
    public static int totalWays(int n){
        if(n<=1)
            return 1;

        //single
        int ways1=totalWays((n-1));

        //pair
        int ways2=totalWays(n-2) *(n-1);

        return ways1+ways2;

    }
    public static void main(String[] args){
        int n=4;
        System.out.println(totalWays(n));
    }
}
