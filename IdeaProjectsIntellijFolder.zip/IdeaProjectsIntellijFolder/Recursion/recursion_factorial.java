package com.hello;
/*
public class recursion_factorial {
    public static void factorial(int i,int n,int fact){
if(i==n){
    fact=fact*i;
    System.out.println(fact);
    return;
}
        fact=fact*i;
        factorial(i+1,n,fact);
    }
    public static void main(String[] args){
        factorial(1,5,1);
    }
}
*/
// another approach
public class recursion_factorial {
    public static int factorial(int n) {
        if (n==1 || n==0) {
            return 1;
        }
      int fact_n_minus_1= factorial(n-1);  //(n-1)!
        int fact_n=n*fact_n_minus_1;           // n*(n-1)!
        return fact_n;
    }

    public static void main(String[] args) {
        int n=5;
        factorial(n);
        System.out.println(factorial(n));
    }
}
