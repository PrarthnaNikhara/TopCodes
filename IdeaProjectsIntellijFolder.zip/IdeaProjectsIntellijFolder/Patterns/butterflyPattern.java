package com.hello;

public class butterflyPattern {
    public static void main(String[] args){
        /*
        for(int i=1;i<=4;i++){
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.print("\n");
        }
        for(int k=4;k>=1;k--){
            for(int l=1;l<=k;l++){
                System.out.print("*");
            }
            System.out.print("\n");
        }
        for(int m=1;m<=4;m++){
            for(int n=1;n<=m;n++){
                System.out.print("*");
            }
            System.out.print("\n");
        }
        for(int k=4;k>=1;k--){
            for(int l=1;l<=k;l++){
                System.out.print("*");
            }
            System.out.print("\n");
        }

         */
        for(int i=1;i<=4;i++) {
            for ( int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            for (int k = 1; k <= 8 - 2 * i; k++) {
                System.out.print(" ");
            }
            for (int l = 1; l <= i; l++) {
                System.out.print("*");
            }
            System.out.print("\n");
        }
        for(int m=4;m>=1;m--) {
            for ( int j = 1; j <= m; j++) {
                System.out.print("*");
            }
            for (int k = 1; k <=8 - 2 * m; k++) {
                System.out.print(" ");
            }
            for (int l = 1; l <= m; l++) {
                System.out.print("*");
            }
            System.out.print("\n");
        }
    }
}
