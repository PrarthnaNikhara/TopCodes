package com.hello;

public class basicPatterns {
    public static void main(String[] args){
       /*
       int i=0,j=0;
        for(i=0;i<5;i++){
            for(j=0;j<5;j++){
                System.out.print("*");
            }
            System.out.println("\n");
        }
        */


/*
 for(int n=0;n<4;n++){
        for(int m=0;m<4;m++){
            if(m==0 || m==3 || n==0 || n==3)
        System.out.print("*");
            else
                System.out.print(" ");
        }
        System.out.println("\n");
        }

 */
     /*
        int p=0,q=0;
        for(p=1;p<=4;p++){
            for(q=0;q<p;q++){
                System.out.print("*");
            }
            System.out.println("\n");
        }

      */
        /*
        int p=0,q=0;
        for(p=4;p>=1;p--){
            for(q=p;q<1;q--){
                System.out.print("*");
            }
            System.out.println("\n");
        }
         */
/*
        for(int u=1;u<=4;u++){
            for(int v=1;v<=(4-u);v++) {
                System.out.print(" ");
            }
                for(int o=1;o<=u;o++) {
                    System.out.print("*");
                }

            System.out.println("\n");
        }
 */

   /* for(int i=1;i<=5;i++){
        for(int j=1;j<=i;j++){
            System.out.print(j + " ");
        }
        System.out.println("\n");

    }
    */
        /*
    for(int i=5;i>=1;i--){
        for(int j=1;j<=i;j++){
            System.out.print(j + " ");
        }
            System.out.print("\n");
    }

         */
/*
        int l=1;
        for(int i=1;i<=5;i++){
            for(int j=1;j<=i;j++){
                System.out.print(l + " ");
                l++;
            }
            System.out.print("\n");
        }

 */
        /*
        for(int i=1;i<=5;i++){
            for(int j=1;j<=i;j++) {
               if((i+j)%2==0)
                System.out.print(1);
               else
                   System.out.print(0);
            }
            System.out.print("\n");
        }
         */


    }
}