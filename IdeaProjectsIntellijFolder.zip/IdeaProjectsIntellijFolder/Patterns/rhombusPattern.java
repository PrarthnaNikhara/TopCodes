package com.hello;
import java.util.Scanner;
public class rhombusPattern {
    public static void main(String[] args){
   /*     Scanner sc= new Scanner(System.in);
        int n= sc.nextInt();
//try with n=9
        for(int i=1;i<=5;i++){
            for(int j=1;j<=(n-1);j++){
                System.out.print(" ");
            }
            for(int k=1;k<=5;k++){
                System.out.print("*");
            }
            System.out.println();
            n--;
        }
*/
        //alternate method
        for(int i=1;i<=5;i++){
            for(int j=1;j<=(5-i);j++){
                System.out.print(" ");
            }
            for(int k=1;k<=5;k++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
