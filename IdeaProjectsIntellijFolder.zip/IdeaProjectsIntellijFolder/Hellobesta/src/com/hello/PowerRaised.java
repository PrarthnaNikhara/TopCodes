package com.hello;
import java.util.Scanner;
public class PowerRaised {
    public static void powerRaised(int x, int n){
        int result=1;
        for(int i=1;i<=n;i++){
            result=result*x;
        }
        System.out.println(result);
    }
    public static void main(String[] args){
            Scanner sc = new Scanner(System.in);
            int a= sc.nextInt();
            int b= sc.nextInt();
        powerRaised(a,b);

    }
}
