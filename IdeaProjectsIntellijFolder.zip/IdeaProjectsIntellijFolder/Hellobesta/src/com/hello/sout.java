package com.hello;

public class sout {
    public static void main(String[] args) {
        System.out.println("beata" +" and "+ "bestiee");
    }
}

