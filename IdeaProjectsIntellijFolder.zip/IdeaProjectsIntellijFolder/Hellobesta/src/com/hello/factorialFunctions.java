package com.hello;
import java.util.*;
public class factorialFunctions {
    public static void printFactorial(int n){
        if(n<0)
            System.out.println("Invalid");
        int factorial =1;
        for(int i=1;i<=n;i++){
            factorial=factorial*i;
        }
        System.out.println(factorial);
        return;
    }
    public static  void main(String[] args){
        Scanner sc= new Scanner(System.in);
        int n=sc.nextInt();
        printFactorial(n);
    }
}
