package com.hello;

public class DoWhile {
    public static void infiniteDoWhile(){
        do{
            System.out.println("Besta");
        }while(true);
    }
    public static void main(String[] args){
        infiniteDoWhile();
    }
}
