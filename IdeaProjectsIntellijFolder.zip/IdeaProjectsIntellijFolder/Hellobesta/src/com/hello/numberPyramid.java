package com.hello;

public class numberPyramid {
    public static void main(String[] args){
        int a=1;
        for(int i=1;i<=5;i++){
            for(int j=1;j<=(5-i);j++){
                System.out.print(" ");
            }
            for(int k=1;k<=a;k++){
                System.out.print(a + " ");
            }
            System.out.println();
            a++;
        }
    }
}
