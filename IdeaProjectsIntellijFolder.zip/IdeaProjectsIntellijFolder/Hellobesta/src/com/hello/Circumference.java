package com.hello;

import java.util.Scanner;

public class Circumference {
    public static float radiusToCircumference(int r){
        float circumference=(2*r*22)/7;
        return circumference;
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int r= sc.nextInt();
        System.out.println( radiusToCircumference(r));
       //checking for r=5 System.out.println(2*5*22/7);

    }
}
