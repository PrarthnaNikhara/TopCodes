package com.hello;
import java.util.*;
public class Strings {
    public static void main(String[] args){
        //string declaration
        String name="Basics of string!";
        //taking input string
        Scanner sc=new Scanner(System.in);
        String inputLine=sc.nextLine();
        String inputWord=sc.next();
        System.out.println();
        System.out.println(inputWord);
        System.out.println(inputLine);
//operations on string
        //concatenation
        System.out.println(inputWord+" "+inputLine);
        String concetanation=inputWord+" "+inputLine;
        System.out.println(concetanation.length());
        //charAt
        for(int i=0;i<concetanation.length();i++){
            System.out.print(concetanation.charAt(i)+"  ");
        }
        //compare
        //if s1>s2:+ve value
        //if s1==s2:0
        //if s1<s2:-ve
        //hello<wello  bcoz a<b and so h<w
        if(inputLine.compareTo(inputWord)==0)
            System.out.println("equal strings");
        else
            System.out.println("unequal strings");


    }
}
