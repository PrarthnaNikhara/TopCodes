package com.hello;

public class factorial {
 public static void calfact(int i, int n, int fact){
            if(n==1 || n==0){
                fact=1;
                return;
            }
            if(i==n){
                fact*=i;
                System.out.print(fact);
                return;
            }
            fact*=i;
            calfact(i+1,n,fact);
        }
        public static void main(String[] args) {
            System.out.println("Hello World");
            calfact(1,5,1);
        }
    }
