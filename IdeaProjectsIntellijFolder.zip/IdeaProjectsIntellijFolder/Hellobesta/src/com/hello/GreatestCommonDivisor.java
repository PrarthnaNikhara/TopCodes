package com.hello;
import java.util.*;
public class GreatestCommonDivisor {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
int n1=sc.nextInt();
int n2=sc.nextInt();
/*if(a>b)
for(int i=0;i<=a;i++){
    if(a%i==0){
        if()
    }
}

 */

        while (n1 != n2) {
            if (n1 > n2) {
                n1 = n1 - n2;
            } else {
                n2 = n2 - n1;
            }
        }
        System.out.println("GCD is : " + n2);
    }
}


