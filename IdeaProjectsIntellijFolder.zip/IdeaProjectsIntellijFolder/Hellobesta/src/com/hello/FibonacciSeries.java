package com.hello;
import java.util.*;
public class FibonacciSeries {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int temp,t1=0,t2=1;
        for(int i=1;i<=n;i++) {
            System.out.println(t1);
            temp = t1+t2;
            t1 =  t2;
            t2 = temp;
        }
    }
}
