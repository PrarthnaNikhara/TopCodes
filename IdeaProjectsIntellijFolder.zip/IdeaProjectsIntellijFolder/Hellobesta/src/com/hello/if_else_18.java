package com.hello;
import java.util.Scanner;
public class if_else_18 {
    public static void adult(int a) {
        if (a >= 18)
            System.out.println("ADULT");
        else
            System.out.println("NOT ADULT");
    }
        public static void main(String[] args){
            Scanner sc=new Scanner(System.in);
            int a=sc.nextInt();
            adult(a);

        }
    }




