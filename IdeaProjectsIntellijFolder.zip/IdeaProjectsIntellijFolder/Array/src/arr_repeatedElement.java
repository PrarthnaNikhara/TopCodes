import java.util.Scanner;

public class arr_repeatedElement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
       /* int n = sc.nextInt();
        int[] NumArray = new int[n];
        //input
        for (int i = 0; i < n; i++) {
            NumArray[i] = sc.nextInt();
        }
        */
        int NumArray[]={1,5,3,4,3,5,6,6,6,6};
        int visited[]={0,0,0,0,0,0,0,0,0,0};
        for(int i=0;i<10;i++){
            int count=1;
            if(visited[i]!=1) {
                for (int l = i + 1; l <10; l++) {
                    if (NumArray[i] == NumArray[l]) {
                       // System.out.println(NumArray[l]+" is repeated no in array ");
                        count++;
                        visited[l]=1;
                         }
                }
                System.out.println("no.of elements repeated " +NumArray[i] +" is:" + count);
            }

        }


    }
}