import java.util.Scanner;

public class _2DArray {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int row=sc.nextInt();
        int col=sc.nextInt();
        int[][] Num2DArray=new int[row][col];
        //input
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                Num2DArray[i][j]=sc.nextInt();
            }
        }
        System.out.println("Element to be found: ");
        int x=sc.nextInt();
        String indexOfx = " ";

        //output
        for(int i=0;i<row;i++) {
            for (int j = 0; j < col; j++) {
                System.out.print(Num2DArray[i][j] + " ");
                //finding index of element x
                if (Num2DArray[i][j] == x) {
                    indexOfx = "index of " + x + " is (" + i + ", " + j + ")";
                }
            }
            System.out.println();
        }
        System.out.println(indexOfx);

    }
}
