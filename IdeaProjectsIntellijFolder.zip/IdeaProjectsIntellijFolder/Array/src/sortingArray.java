public class sortingArray {
    public static void main(String[] args){
        int[] array ={7,3,8,2,1};
 //bubble sort
       /* for(int i=0;i<array.length-1;i++){
            for(int j=0;j<array.length-1-i;j++){
                if(array[j]>array[j+1]){
                    int temp=array[j];
                    array[j]=array[j+1];
                    array[j+1]=temp;
                }
            }
        }
       */


//selection sort
      /*  for(int i=0;i<array.length-1;i++) {
            for (int j = i+1; j < array.length; j++) {
               if(array[j]<array[i]){
                   int temp=array[j];
                   array[j]=array[i];
                   array[i]=temp;;
               }
            }
         }
       */


//insertion sort
        for(int i=1;i<array.length;i++) {
            int current=array[i];
            int j=i-1;
            while (j>=0 && current<array[j]) {
                   array[j+1]=array[j];
            j--;
            }
            //placement
            array[j+1]=current;
        }





        //print array
        for(int i=0;i<array.length;i++){
            System.out.print(array[i]+" ");
        }

        System.out.println();
        System.out.print("length of array : "+ array.length);
    }
}
