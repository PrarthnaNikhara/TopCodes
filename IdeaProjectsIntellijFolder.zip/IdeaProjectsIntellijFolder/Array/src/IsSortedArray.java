import java.util.Scanner;

public class IsSortedArray {
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        int size=sc.nextInt();
        int isArraySorted[] =new int[size];
        for(int i=0;i<size;i++){
            isArraySorted[i]=sc.nextInt();
        }
        boolean isSorted=true;
        for(int i=0;i<isArraySorted.length -1;i++){
            if(isArraySorted[i]>isArraySorted[i+1])
                isSorted=false;
                }
        if(isSorted)
        System.out.println("Array is sorted");
        else
        System.out.println("Array not Sorted");

    }
}
