import java.util.Scanner;

public class Spiral2DArray {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int m=sc.nextInt();
        int[][] spiralMatrix= new int[n][m];
     //input
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                spiralMatrix[i][j]=sc.nextInt();
            }
        }
        //spiral matrix
        int row_start=0,row_end=n-1,col_start=0,col_end=m-1;

        while(row_start<=row_end && col_start<=col_end){
        for(int col=col_start;col<=col_end;col++){
        System.out.print(spiralMatrix[row_start][col]+" ");
         }
        row_start++;
            for(int row=row_start;row<=row_end;row++){
                System.out.print(spiralMatrix[row][col_end]+" ");
            }
            col_end--;

            for(int col=col_end;col>=col_start;col--){
                System.out.print(spiralMatrix[row_end][col]+" ");
            }
            row_end--;

            for(int row=row_end;row>=row_start;row--){
                System.out.print(spiralMatrix[row][col_start]+" ");
            }
            col_start++;
            System.out.println();

        }


    }
}
