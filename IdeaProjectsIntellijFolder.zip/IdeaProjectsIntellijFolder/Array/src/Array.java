import java.util.Scanner;

public class Array {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int size=sc.nextInt();
        int arrayName[] =new int[size];
        for(int i=0;i<size;i++){
            arrayName[i]=sc.nextInt();
        }

        for(int i=0;i<size;i++) {
            System.out.println("Element at index "+ i+ " is "+arrayName[i]);
            if (arrayName[i] == 5) {
                System.out.println("5 is at index : " + i);
            }
        }
        // int max=0,min=99999;

        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;
        for(int i=0;i<arrayName.length;i++){
            if(arrayName[i]<=min) {
                min = arrayName[i];
            }

            if(arrayName[i]>=max) {
                max = arrayName[i];
            }

        }
        System.out.println("Minimum: "+min);
        System.out.println("Maximum: "+max);
    }
}
