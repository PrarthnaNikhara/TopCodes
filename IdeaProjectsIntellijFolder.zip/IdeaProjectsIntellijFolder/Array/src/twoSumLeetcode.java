import java.util.*;
public class twoSumLeetcode {
            public static void main(String[] args){
            //  vector<int> twoSum(vector<int>& nums, int target) {
            int size;
                Scanner sc = new Scanner(System.in);
                size = sc.nextInt();
            int arr[] = new int [size];
            for(int i=0;i<size;i++){
                 arr[i]=sc.nextInt();
            }
            int target = sc.nextInt();
            //arr.sort;
            for(int i=0;i<size;i++){
                for (int j = i + 1; j < size; j++) {
                    if (arr[i] + arr[j] == target) {
                        System.out.print(i +" "+j);
                    }
                }
            }
            //  }
    }
}
