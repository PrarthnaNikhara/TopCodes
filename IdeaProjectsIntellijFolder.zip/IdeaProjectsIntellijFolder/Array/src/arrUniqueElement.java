//find unique element

public class arrUniqueElement   {
    public static void main(String[] args) {
       /* Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] NumArray = new int[n];
        //input
        for (int i = 0; i < n; i++) {
            NumArray[i] = sc.nextInt();
        }
        */
        int n=6;
        int NumArray[]={11,12,13,12,11,11};
        int visited[]=new int[n];
        for(int i=0;i<n;i++){
            int count=1;
            if(visited[i] !=1) {
                for (int l = i + 1; l < n; l++) {
                    if (NumArray[i] == NumArray[l]) {
                        System.out.println(NumArray[i]);
                        visited[l] = 1;
                        count++;
                    }
                }
                System.out.println("Count of " + NumArray[i] + " : "+ count);
            }
        }


    }
}