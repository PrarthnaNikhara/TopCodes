//class name =  capital letter
//fn name =small letter

//constructor has the same name as the class
//constructor are fns without return type
//constructor is only called once when object is created
//Constructor is used to construct objects
//3 type of constructor = non-parametrize  parametrize


//destructor = to destroy the obj
//c++ m jese constructor likhte h vese distructor fn bhi likhte h
//java m destructor nhi lihte yui garbage collector exist krta h jo automatically unused obj ya memory ko garbage/delete krdeta h
class  Pen{
    String color;
    String type; //ball gel

    //fn inside class= method
    public void write(){
        System.out.println("Writing something");
    }

    public void printColor(){
        System.out.println(this.color);
    }
}

class Student{
    String name;
    int age;

    public void printInfo(){
        System.out.println(this.name);
        System.out.println(this.age);
    }

    /*
    //non-parametrize constructor
    Student(){
        System.out.println("constructor called!");
    }

     */



    /*
    //parametrize constructor
    Student(String name,int age){
        this.name =name;  // name is the parameter of constructor Student
                          //this.name is parameter of class Student
        this.age=age;
    }

     */



    //copy constructor //to copy obj or property of obj
    Student(Student s4){
        this.name=s4.name;
        this.age=s4.age;
    }

    Student() {
    }
}

public class oops {
    public static void main(String args[]) {


       /*
        Pen pen1 = new Pen();
        pen1.color ="Blue";
        pen1.type="Ball";

        Pen pen2 = new Pen();
        pen2.color= "black";
        pen2.type="gel";

        pen1.write();
        pen1.printColor();
        pen2.printColor();

        */



         /*
         //for non-parametrize constructor
        Student s1 =new Student();

        //Student() is known as Constructor

        s1.name="Priya";
        s1.age=12;

        Student s2=new Student();
        s2.name="Pranjal";
        s2.age=37;

        s2.printInfo();

        */



        /*
        //for non-parametrize constructor
        Student s3=new Student("Priya", 12);
        s3.printInfo();

         */



        /*
        //for copy constructor
        Student s4 = new Student();
        s4.name="raj";
        s4.age=34;

        Student s5 = new Student(s4);
        s5.printInfo();

         */

    }
}

//OOPS -> polymorphism abstraction encapsulation inheritance
