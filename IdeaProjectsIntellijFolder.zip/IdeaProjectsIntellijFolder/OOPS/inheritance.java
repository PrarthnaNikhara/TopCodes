//one class can inherit the properties or/and methods of another class

import java.util.*;
//encapsulation
// import bank;
class Shape {
    String color;
    public void area(){
        System.out.println("Displays area");
    }
}

//single-level
class Triangle extends Shape{
    public void area(int l, int h){
        System.out.println(1/2*l*h);
    }

}

//multi-level
class EquilateralTriangle extends Triangle{
    public void area(int l){
        System.out.println(1/2*l*l);
    }

}

//hierarchial -> 1 base class + multiple child class
class Circle extends Shape{
    public void area(int r){
        System.out.println( (3.14) *r *r );
    }
}

//hybrid -> combo of types of inheritance

//multiple inheritance -> java m classes  andr nhi hota , c++ m hota h , java m interfaces use krte h usse implement krne k liye
public class inheritance {
    public static void main(String[] args){
        Triangle t1=new Triangle();
        t1.color="red";

        /*
        //encapsulation
        bank.Account a1 =new bank.Account();
        a1.name="SBI";

         */

    }
}
