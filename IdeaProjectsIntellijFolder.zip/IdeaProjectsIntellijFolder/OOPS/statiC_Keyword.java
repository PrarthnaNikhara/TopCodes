class Studentss {
    String namee;
    static String school; // static means fix , school name is same or fix for each student

    public static void chanageSchool(){
        school = "newSchool";
    }

}
public class statiC_Keyword {
    public static void main(String[] args){
          Studentss.school = "JMV";
          Studentss student01 = new Studentss();
          student01.namee = "tony";
        System.out.println(student01.school);
    }
}
