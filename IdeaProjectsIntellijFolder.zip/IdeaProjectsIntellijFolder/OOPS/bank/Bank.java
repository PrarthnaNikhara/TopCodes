//package -> related code
// 2types ->built-in & user-defined

/*
access modifiers
in java 4 types
in c++ 3 types
defines-> konsi chez kisko accessible hogi

1.public -> koi bhi access kr skta h is class m bhi aur kisi aur class
 m bhi
2.private ->sirf vahi class access kr skti h koi aur class nhi na koi
 subclass
3.protected-> use apne package m sari cheze access kr skti h aur
 dusre package m krna h to sirf subclasses
4.default-> apne package k andr ki sari classes use access kr skti h bass
 koi dusra package use access nhi kr skta h
 */



package bank;

class Account{
public String name;
protected String email;
private String password;
//getters & setters

    public String getPassword(){
        return this.password;
    }

    public void setPassword(String pass){
        this.password=pass;
    }

    /*
    to give a random password from code
    make the setPassword fn private instead of public
    add this line
    setPassword(randomPass);
    in the getPassword fn before return statement
     */
}
public class Bank  {
    public static void main(String args[]){
        Account account1 = new Account();
        account1.name = "Apna college";
        account1.email = "apnacollege@email.com";
       // account1.password ="abcd"; //error
        account1.setPassword("abcd");
        System.out.println(account1.getPassword());

    }
}

/*
Encapsulation = data(properties) and methods into single unit(class)
Hiding data is possible through encapsulation
using access modifiers
 */
/*
Abstraction = important cheeze user ko dikhana aur
non-imp(faltu) cheze chhupa lena

2 ways s implement krte h
using abstract keyword
using interfaces
 */