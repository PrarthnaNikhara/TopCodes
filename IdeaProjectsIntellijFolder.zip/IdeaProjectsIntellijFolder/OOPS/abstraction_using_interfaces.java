//multiple inheritance means 2 base class 1 derived class
//multiple inheritance java m classes k through nhi interfaces k through possible h

interface Animals{
   void walk();

   // Animal{} //error //can't create constructor
  //  void eat(){}; //non-abstract nhi chlega , interface m sab kuch abstract hona chahiye i.e. pure abstract
    int eyes =2;//static (= fix) //public
}

interface Herbivores {

}
class Horses implements Animals, Herbivores{
  public  void walk(){
        System.out.print("4 legs");
    }
}

public class abstraction_using_interfaces {
    public static void main(String[] args){
        Horses horse = new Horses();
        horse.walk();
    }
}
