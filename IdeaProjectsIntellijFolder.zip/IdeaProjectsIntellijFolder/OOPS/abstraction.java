//by using abstract Animal class will not show to user as user do not need properties of animal user needs horse and chicken and horse and chicken class has already extended animal class properties so the user do not need to go inside animal class to see the properties written inside it

abstract class Animal{
    //public void walk(){}
    abstract void walk();

    //non-abstract method
    public void eat(){
        System.out.println("Eats");
    }

    //constructor
    Animal(){
        System.out.println("You are an animal");
    }
}

class Horse extends Animal{

    //constructor
    Horse(){
        System.out.println("I am horse");
    }
    @Override
    public void walk() {
        System.out.println("Walks on 4 legs");
    }
}

class Chicken extends Animal{
    public void walk() {
        System.out.println("Walks on 2 legs");
    }
}


public class abstraction {
    public static void main(String[] args){
       Horse horse= new Horse();
       horse.walk();
       horse.eat();
/*
       Animal animal = new Animal(); //can't create obj of Animal boz it is abstract
       animal.walk();
*/

    }
}
