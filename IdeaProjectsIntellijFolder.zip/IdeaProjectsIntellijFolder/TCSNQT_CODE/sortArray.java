public class sortArray {
    public static void main(String args[]){
        int arr[] = {0,3,7,5};
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr.length;j++)
            if(arr[i]<arr[j]){     //ASC
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
                for(int  p =0;p<arr.length;p++){
                    System.out.print(arr[p]+" ");
                }
                System.out.println();
            }
        }
        System.out.println("ASC ORDER OF ARRAY : ");
        for(int  i =0;i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
