import java.util.Scanner;

public class secondLargestAndSmallestElementInArray {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();

        int arr[] = new int[size];
        for(int  i =0; i < size; i++){
            arr[i] = sc.nextInt();
        }

        int min = arr[1];
        int secondMin = 999999999;
        int max = arr[0];
        int secondMax=-999999999;
        for(int  i =0; i < size; i++){
            if(arr[i]<=min){
                secondMin = min;// not working for array 2,1,3,4,5
                min = arr[i];
            }
            else{
                secondMax = max;//this will not work in case of descending sorted array
                max = arr[i];
            }
        }

        System.out.println("Second minimum number of array is:" +secondMin);
        System.out.print("Second maximum number of array is:" +secondMax );
    }
}
