import java.util.Arrays;
public class CountNonRepeatingElementsOfArray {
    public static void main(String[] args){
        int arr[] = {1,2,3,4,3,2};
        int n =arr.length;
        boolean visited[] = new boolean[n];
        int count_distinct=0;
        for(int i=0;i<n;i++){
            if(visited[i]){
                continue;
            }
            int count =1;
            for(int j =i+1;j<n;j++) {
                if (arr[i] == arr[j]) {
                    visited[j] = true;
                    count++;
                }
            }
            if(count ==1){
                System.out.println(arr[i] +" is non- repeating element");
                count_distinct++;
            }
        }
        System.out.println("total non repeating elements in array : "+ count_distinct);
    }
}
