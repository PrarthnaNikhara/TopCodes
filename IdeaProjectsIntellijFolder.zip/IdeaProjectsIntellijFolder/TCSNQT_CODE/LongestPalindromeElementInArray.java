import java.util.*;
public class LongestPalindromeElementInArray {
    public static boolean isPalindrome(int n){
        int temp = n;
        int reverse=0;
        while(temp!=0){
            reverse = reverse*10 + (temp%10);
            temp=temp/10;
        }
        if(n == reverse){
            return true;
        }
        return false;
    }
public static void main(String args[]){
        int arr[] = {12,3,101,343,03};
        int n = arr.length;
      //  Arrays.sort(arr);
        int result=0;
        for(int i =0;i<=n-1;i++){
            if(isPalindrome(arr[i]) && result<arr[i]){
                result=arr[i];
               }
            }
    System.out.println(result);
        }
 }

