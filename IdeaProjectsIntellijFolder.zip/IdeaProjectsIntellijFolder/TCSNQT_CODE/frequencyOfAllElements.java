import java.util.Arrays;
public class frequencyOfAllElements {
 public static void main(String args[]){
        int arr[]= {1,2,3,4,3,2,1};
        Arrays.sort(arr);
        for(int i=0;i<arr.length;i++){
            int count=1;
            for(int j=i+1;j<arr.length;j++){

                if(arr[i]==arr[j]){
                    count++;
                }
            }

            System.out.println(arr[i]+" has frequency of "+ count);
            while(arr[i]==arr[i+1]){
                i++;
            }
        }
    }
}
