import java.util.Arrays;

public class median {
    public static void main(String args[]){
        int arr[] = {2,4,6,2};
        int n = arr.length;
        Arrays.sort(arr);

        if(n%2!=0)
        System.out.println(arr[(n+1)/2]);
        else
            System.out.println( (arr[(n/2) -1] + arr[(n/2)] )/2);
    }
}
