public class reverseArray {
    public static void main(String args[]){
        int arr[] = {0,2,3,4,5,5};
        for(int i =0; i<arr.length/2; i++){
            int  temp= arr[i];
            arr[i] = arr[arr.length-1-i];
            arr[arr.length-1-i] = temp;
        }
        for(int i=0;i<arr.length; i++){
            System.out.print(arr[i]+" ");
        }
    }
}
/*
for (int i=arr.length-1;i>=0;i--){
sout(arr[i]+ " ");
}
 */