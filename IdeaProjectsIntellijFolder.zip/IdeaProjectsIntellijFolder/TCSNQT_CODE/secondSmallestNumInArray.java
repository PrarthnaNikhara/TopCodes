public class secondSmallestNumInArray {
    public static void main(String[] args){
      //  int arr[]={5,4,3,2,1};
       // int arr[]={1,2,3,4,5};
        int arr[]={1};
        int min =Integer.MAX_VALUE;
        int secmin= Integer.MIN_VALUE;
        for(int i =0;i<arr.length;i++){
            if(arr[i]<min){
                secmin= min;
                min=arr[i];
            }
            else if(secmin>arr[i]){
                secmin=arr[i];
                System.out.println(secmin);
            }
        }
        System.out.println(secmin);
    }
}
