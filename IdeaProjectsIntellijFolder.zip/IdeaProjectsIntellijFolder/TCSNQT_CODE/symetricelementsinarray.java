public class symetricelementsinarray {
    public static void main(String args[]){
        int array2d[][]= {{1,2},{3,4},{1,4},{2,1}};
        int row=4;
        int col=2;
        for(int i =0;i<row;i++){
            for(int j =i+1;j<row;j++){
                if((array2d[i][0] == array2d[j][1]) && (array2d[i][1]==array2d[j][0])){
                    System.out.println(array2d[i][0]+" , "+ array2d[j][1]);
                }
            }
        }
    }
}
