import java.util.Arrays;

public class frequencyOfElementsOfArray {
    public static void main(String[] args){
        int arr[] ={1,2,3,3,2,1,1,2,0,89};
        int n =arr.length;
        boolean visited[] = new boolean[n];
        Arrays.fill(visited, false);

        for(int i =0;i<arr.length;i++){
            if(visited[i]){
                continue;
            }
            int count =1;

            for(int j=i+1;j<arr.length;j++){
                if(arr[i]==arr[j]){
                    count++;
                    visited[j]= true;
                }
            }
            System.out.println("Frequenct of element " + arr[i] + " is : " +count );
        }
    }
}
