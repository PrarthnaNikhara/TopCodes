public class printtheFNthterm {
    public static void main(String[] args){
        int n = 4; //1+(2*3)+(4*5*6)+(7*8*9*10) = 5167
        int sum=0;
        int num=1;
        for(int i =1;i<=n;i++){
           int multi =1;
            for(int j=1;j<=i;j++){
                multi=multi*num;
                num++;
            }
            sum=sum+multi;
        }
        System.out.println(sum);
    }
}
