public class countEvenOddElementsInArray {
    public static void main(String[] args){
        int arr[] = {1,2,3,4,4};
        int n = arr.length;
        int countEven=0, countOdd=0;
        for(int i=0;i<n;i++){
            if(arr[i]%2 == 0)
                countEven++;
            else
                countOdd++;
        }
        System.out.println("no of even numbers : "+ countEven);
        System.out.println("no of odd numbers : "+ countOdd);
    }
}
