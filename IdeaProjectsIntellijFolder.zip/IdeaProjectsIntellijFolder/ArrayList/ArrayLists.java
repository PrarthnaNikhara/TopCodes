import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collector;

public class ArrayLists {
    public static void main(String[] args){
      // Integer | Float | String | Boolean   ->classes of int float str boolean resp.
        //for arraylist making we use above classes
        ArrayList<Integer> list1 = new ArrayList<Integer>();
        //ArrayList<Float> list2 = new ArrayList<Float>();
        //ArrayList<String> list3 = new ArrayList<String>();
        //ArrayList<Boolean> list4 = new ArrayList<Boolean>();

        list1 .add(10);
        list1.add(1);

        System.out.println(list1);// 10,1

        //get elements
        int element =list1.get(0); //0 is index
        System.out.println(element);//10

        //add element in btw
        list1.add(1,6); // idx,ele
        System.out.println(list1);//10,6,1

        //set element
        list1.set(2,5);//idx,newEle
        System.out.println(list1);//10,6,5

        //remove ele
        list1.remove(2);//idx
        System.out.println(list1);//10,6

        //size
        int size = list1.size();
        System.out.println(size);//2

        //loops
        for(int i = 0;i < list1.size(); i++){
            System.out.print(list1.get(i));//10 6
        }
        System.out.println();

        //sorting
        Collections.sort(list1);
        System.out.println(list1);//6,10
    }
}
