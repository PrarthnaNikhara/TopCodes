public class harshadNumber {
    public static void main(String args[]){
        int num = 24;//sumofdigits 2+4=6 -> 24%6==0-> harshad number
        int temp = num;
        int sum = 0;
        while(temp!=0){
           sum = sum+temp%10;
           temp = temp/10;
        }

        if(num%sum==0){
            System.out.print(num +" is harshad number");
        }
        else{
            System.out.print(num +" is not harshad number");
        }
    }
}
