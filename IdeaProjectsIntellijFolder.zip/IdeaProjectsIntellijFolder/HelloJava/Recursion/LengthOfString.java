public class LengthOfString {
    static int lengthString(String str){
        if(str.equals("")){
            return 0;
        }

        return lengthString(str.substring(1))+1;
    }
    public static void main(String args[]){
        String str = "abcd";
        System.out.print(lengthString(str));
    }
}
