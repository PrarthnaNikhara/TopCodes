public class FNth_term {
    public static void main(String args[]){
        int n =3;
        nthTerm(n);
    }

    static void nthTerm(int n){
        int sum=0,multi=1,p=1;
        for(int i = 1 ;i <= n;i++){
            for(int j =i;j<=i;j++){
                multi=multi*j;
               p++;
            }
            sum=sum+multi;
        }
        System.out.print(sum);
    }

}
