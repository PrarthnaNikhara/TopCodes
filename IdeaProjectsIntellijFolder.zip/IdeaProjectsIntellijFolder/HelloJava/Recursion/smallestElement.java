public class smallestElement {
    static int smallestEle(int[] arr){
        int min = arr[0];
        for(int i = 1;i<arr.length;i++){
            if(arr[i]<min){
                min = arr[i];
            }
        }
        return min;
    }
    public static void main(String args[]){
        int[] arr = {12,56,76,98,0,43};
        System.out.print(smallestEle(arr));
    }
}
