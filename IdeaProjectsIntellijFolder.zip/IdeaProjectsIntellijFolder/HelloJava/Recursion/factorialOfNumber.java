package Recursion;

public class factorialOfNumber {
            static int factorialOfNum(int number){
            if(number == 0 || number ==1){
                return 1;
            }
            return number*factorialOfNum(number-1);
        }
        public static void main(String[] args){
                int num =10;
            System.out.println(factorialOfNum(num));
        }

    }
