package Recursion;
public class reverseOfNumber {
/*
    static int reverse(int num){
        int reverse = 0;
        while(num!=0){
            reverse = reverse*10 + num%10;
            num = num/10;
        }
        return reverse;
    }

 */
    static void reverse(int num){
        if(num < 10){
            System.out.println(num);
        }
        else {
            System.out.print(num % 10);
            reverse(num/10);
        }
    }
    public static void main(String args[]){
        int number = 110098;
        reverse(number);
    }
}
