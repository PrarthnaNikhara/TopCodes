public class powerOFNumber {
    public static void main(String args[]){
        int num = 2;
        int pow = 4;
        System.out.print(powerOfNum(num,pow));
    }
    static int powerOfNum(int base, int power){
        if (power == 0) {
            return 1;
        }
        return (base*powerOfNum(base,power-1));
    }
}
