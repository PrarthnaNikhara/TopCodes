public class permutationsOfString {
    public static void main(String args[]){
        String str = "ABC";
      permutationOfStr(str," ");
    }
    static void permutationOfStr(String string,String ans){
        if(string.length()==0){
            System.out.print(ans+" ");
          //  return;
        }
        for(int i =0;i<string.length();i++){
            char ch = string.charAt(i);
            String r = string.substring(0,i) + string.substring(i+1);
            permutationOfStr(r,ans+ch);
        }
    }
}
