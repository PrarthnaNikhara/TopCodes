public class strongNumber {
    public static void main(String args[]){
        int num = 145;
        int temp = num;
        int sum = 0;
        while(temp!=0){
            sum += fact(temp%10);
            temp = temp/10;
        }

        if(num == sum){
            System.out.print("Strong Number");
        }
        else {
            System.out.print("Not a strong number");
        }
    }
    static int fact(int x){
        /*
        if(x==0 || x==1)
            return 1;


        return x*fact(x-1);

         */

        int factorial = 1;
        for(int i =2;i<=x;i++){
            factorial *=i;
        }
        return factorial;
    }
}
