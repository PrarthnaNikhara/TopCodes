package Numbers;
import java.util.*;
public class QuadraticEquationRoots {
public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            int a, b, c;
            a = sc.nextInt();
            b = sc.nextInt();
            c = sc.nextInt();

            if (a == 0) {
                System.out.println("Invalid: 'a' coefficient cannot be zero");
                return;
            }

            double d = b * b - 4 * a * c;

            if (d > 0) {
                double root1 = (-b + Math.sqrt(d)) / (2 * a);
                double root2 = (-b - Math.sqrt(d)) / (2 * a);
                System.out.println("Root 1: " + root1);
                System.out.println("Root 2: " + root2);
            } else if (d == 0) {
                double root1 = -b / (2 * a);
               // double root2 = -b / (2 * a);
                System.out.println("Roots are real and equal. Root: " + root1);
            } else {
                double realPart = -b / (2 * a);
                double imaginaryPart = Math.sqrt(-d) / (2 * a);
                System.out.println("Roots are complex.");
                System.out.println("Root 1: " + realPart + " + i" + imaginaryPart);
                System.out.println("Root 2: " + realPart + " - i" + imaginaryPart);
            }
        }
    }

