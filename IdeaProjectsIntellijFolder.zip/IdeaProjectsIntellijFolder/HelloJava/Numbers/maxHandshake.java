package Numbers;

public class maxHandshake {
    public static void main(String args[]){
            int numOfPeople = 5;
            int total = ( (numOfPeople-1) * numOfPeople ) /2;
        System.out.println("For "+ numOfPeople +" people there will be " +total+" handshakes");
    }
}
