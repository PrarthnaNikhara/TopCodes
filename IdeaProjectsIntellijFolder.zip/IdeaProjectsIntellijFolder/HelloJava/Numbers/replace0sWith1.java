package Numbers;
// replace 0's with 1 in integer
public class replace0sWith1 {
    public static void main(String args[]){
        int n = 2110087;
        String s1 = "";

        while(n!=0){
            if( n%10!=0){
                s1=s1+n%10;
            }
            else{
                s1=s1+"1";
            }
            n=n/10;
        }

        for(int i = s1.length()-1; i>=0 ;i--) {
            System.out.print(s1.charAt(i));
        }
    }
}
