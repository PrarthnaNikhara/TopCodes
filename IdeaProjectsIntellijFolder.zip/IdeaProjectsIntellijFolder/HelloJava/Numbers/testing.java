package Numbers;

public class testing {
    public static void main(String args[]) {
      for(int i =0;i<0;i++){
          if(i==5){
              break;
          }
          if(i==3){
              continue;
          }
          System.out.println(i);
 }
      String ab="bac";
      //String bc ="b";
       // System.out.println(ab.equals(bc));
        //System.out.println(ab.compareTo(bc));
        ab="abccc";
        System.out.println( ab.substring(0));
    }
}