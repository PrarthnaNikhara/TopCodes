package Numbers;

public class numberOfDigits {
    public static void main(String[] args){
        int n =0023750;
        int len =0;
        while(n!=0){
            len++;
            n=n/10;
        }
        System.out.println(len);
    }
}
