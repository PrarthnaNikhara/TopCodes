package Numbers;

public class numberOfIntegersWithExactxDivisors {
    public static void main(String[] args){
        int n = 17;
        int x = 3;
        //check till 17 how many integers have exactly 3 factors/divisors
        int count =0;
        for(int i =0; i<=n;i++){
            int count_factors=0;
            for(int j=1;j<=i;j++){
                if(i%j==0){
                    count_factors++;
                }

            }
            if(count_factors==3){
                System.out.println(i+" has exactly "+x+" divisors");
                count++;
            }
        }
        System.out.println("total integers that has exactly " + x + " divisors are :"+ count);
    }
}
