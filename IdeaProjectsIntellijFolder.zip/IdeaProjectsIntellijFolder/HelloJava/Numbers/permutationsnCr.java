package Numbers;
//permutations in which n people can occupy r seats in a classroom
public class permutationsnCr {
    public static void main(String args[]){
        int n = 5;
        int r = 3;
        System.out.print(factorial(n)/factorial(n-r));
    }
    static int factorial(int num){
        if(num==0 || num==1){
            return 1;
        }
        int fact=1;
        for(int i =1;i<=num;i++){
            fact = fact*i;
        }
        return fact;
    }
}
