package Numbers;

public class canANumberBeExpressedAsSumOfTwoPrimeNumbers {
    public static void main(String args[]){
        int n = 14;
        for(int i = 2 ; i <= n/2 ; i++){
            if(n%i!=0){
                if((n-i)%i != 0){
                    System.out.println("YES, "+ i + " + " + (n-i) + " = " + n + " and " + n +" and " + (n-i) +" are prime numbers");
                }
            }
        }
    }
}
