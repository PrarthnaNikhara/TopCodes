package Numbers;

import java.util.Scanner;

public class quadrantInWhichCoordinateLies {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        int y = sc.nextInt();
        if(x==0 && y==0){
            System.out.print("Origin");
        }
        else if(x>0 && y==0 || x<0 && y==0){
            System.out.print("X-axis");
        }
        else if(x==0 && y>0 || x==0 && y<0){
            System.out.print("Y-axis");
        }
        else if(x>0 && y>0){
            System.out.print("1st Quadrant");
        }
        else if(x<0 && y>0){
            System.out.print("2nd Quadrant");
        }
        else if(x<0 && y<0){
            System.out.print("3rd Quadrant");
        }
        else if(x>0 && y<0){
            System.out.print("4th Quadrant");
        }
    }
}
