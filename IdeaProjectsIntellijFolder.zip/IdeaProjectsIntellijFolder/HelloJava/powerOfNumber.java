public class powerOfNumber {
    public static void main(String[] args){
        double num = 5.0;//base
        int power = 3;//exponential

        System.out.print((int)Math.pow(num,power));
/*
        double expoOfBase = 1;

        while(power!=0){
            expoOfBase *= num;
            power--;
        }
        System.out.print(expoOfBase);

 */
    }
}
