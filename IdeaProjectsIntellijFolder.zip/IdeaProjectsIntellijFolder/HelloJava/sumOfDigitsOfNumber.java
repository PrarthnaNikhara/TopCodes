import java.util.Scanner;

public class sumOfDigitsOfNumber {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int temp = num;
       /*

        int sumOfDigits = 0;
        while(num!=0){
           sumOfDigits = sumOfDigits + num%10;
           num=num/10;
        }
        System.out.println(sumOfDigits + " is the sum of digits of " + temp);

         */
        System.out.print(getSum(temp,0));

    }

  static  int getSum(int num, int sumOfDigit) {
        if(num==0){
            return sumOfDigit;
}
         sumOfDigit = sumOfDigit + num%10;
         return getSum(num/10 , sumOfDigit);
    }
}



