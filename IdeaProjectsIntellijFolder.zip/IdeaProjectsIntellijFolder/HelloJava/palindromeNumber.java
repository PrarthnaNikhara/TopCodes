//import org.w3c.dom.ls.LSOutput;

public class palindromeNumber {
    public static void main(String[] args){
        int num = 121;//1221 abc abbc
        int temp = num;
        int reverse = 0;
        while(temp!=0){
            reverse = reverse*10 +temp%10;
            temp = temp/10;
        }
        if(num==reverse)
            System.out.print("Palindrome.");

    else
            System.out.print("Not Palindrome.");
    }

}
