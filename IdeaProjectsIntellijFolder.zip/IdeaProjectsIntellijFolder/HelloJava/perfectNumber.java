public class perfectNumber {
    public static void main(String[] args){
        int num = 6;
        //sum of factors of number(except number itself) is equal to number
        int result = 0;
       for(int i = 1;i<=num/2;i++){
           if(num%i == 0){
               result = result+i;
           }
       }
        if (result == num) {
            System.out.print("PERFECT NUMBER");
        }
        else {
            System.out.print("NOT A PERFECT NUMBER");
        }
    }
}
