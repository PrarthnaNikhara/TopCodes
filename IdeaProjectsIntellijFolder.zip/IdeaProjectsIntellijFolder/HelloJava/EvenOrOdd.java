import java.util.Scanner;
public class EvenOrOdd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();

       System.out.print(num%2==0 ? "Even": "Odd");
    }
}
/*
 if (num % 2 == 0) {
            System.out.print("Even");
        } else {
            System.out.print("Odd");
        }
 */