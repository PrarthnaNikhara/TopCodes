public class sumOfNumInRange {
    public static void main(String[] args){
        int mini = 2;
        int maxi = 4;
        int sum = 0;
        for(int i =mini; i <= maxi; i++){
            sum +=i;
        }
        System.out.print(sum);
    }
}
