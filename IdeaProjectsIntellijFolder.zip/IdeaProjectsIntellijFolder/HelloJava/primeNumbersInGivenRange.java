public class primeNumbersInGivenRange {
    public static void main(String[] args){
        int min = 5;
        int max =50;

        for(int i =min;i<=max;i++){
            int isPrime = 1;
            for(int j=2;j<=(i/2);j++){
                if(i%j==0){
                    isPrime=0;
                    continue;
                }
            }
            if(isPrime==1){
                System.out.println(i+" is prime");
            }
        }

    }
}
