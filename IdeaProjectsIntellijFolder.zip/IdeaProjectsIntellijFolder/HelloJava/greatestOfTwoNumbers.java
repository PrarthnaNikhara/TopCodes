public class greatestOfTwoNumbers {
    public static void main(String[] args){
        int num1 = 5;
        int num2 = -5;
        System.out.print(num1>num2?num1+" is greater":num2+" is greater");
    }
}
/*
if_else
 */