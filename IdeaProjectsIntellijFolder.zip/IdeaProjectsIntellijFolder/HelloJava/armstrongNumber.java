public class armstrongNumber {
    public static void main(String[] args){
        int num = 371; //3^3+7^3+1^3=371
        int temp = num;
        int arm = 0;
        int len = order(num);
        while(temp!=0){
            arm = arm+ (int)Math.pow(temp%10,len);
            temp = temp/10;
        }
        if(num==arm){
            System.out.print("Armstrong");
        }

        else{
            System.out.print("Not Armstrong");
        }
    }
    static int order(int num){
        int len = 0;
        /*
        if(num==0){
            return len;
        }

         */
        while(num!=0){
            len++;
            num = num/10;
        }
        return len;
    }
}
