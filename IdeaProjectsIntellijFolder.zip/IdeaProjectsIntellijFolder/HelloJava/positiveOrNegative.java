public class positiveOrNegative {
    public static void main(String [] args){
        int num = -3;

        if(num == 0){
            System.out.print("Zero");
        }
        else{
            System.out.print(num>0? "Positive" : "Negative");
        }
    }
}
/*
if(num > 0){
            System.out.print("Positive");
        }
        else if(num < 0){
            System.out.print("Negative");
        }
        else{
            System.out.print("Zero");
        }
 */

