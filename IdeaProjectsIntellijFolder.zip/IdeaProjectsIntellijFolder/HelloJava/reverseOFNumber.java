public class reverseOFNumber {
    public static void main(String[] args){
        int num = 7823;
        int temp = num;
        /*
        int reverse = 0;
        while(num!=0){
            reverse = reverse*10 + num%10;

            num = num/10;
        }
        System.out.print(reverse + " is the reverse of "+ temp);

         */
        System.out.print( reverse(7825,0));

    }
    static int reverse(int num, int reverseNum){
        if(num == 0){
            return reverseNum;
        }
        reverseNum = reverseNum*10 + num%10;
        return reverse(num/10,reverseNum);
    }
}

