public class friendlyPair {
    public static void main(String args[]){
        int num1 = 6;//sum factors except num itself = 1+2+3 = 6 -> num/sum = 6/6 =1
        int num2 =28;//sum factors except num itself = 1+2+4+7+14 = 28 -> num/sum = 28/28 =1
        //and (ratio) 1 , 1 are same so 6,28 is friendly pair
        int sum1=0,sum2=0;
        for(int i1=1;i1<=num1/2;i1++){
            if(num1%i1==0){
                sum1= sum1+i1;
            }
        }
        for(int i2=1;i2<=num2/2;i2++){
            if(num2%i2==0){
                sum2= sum2+i2;
            }
        }

        if(num1/sum1 == num2/sum2){
            System.out.print(num1 +" , "+num2+" are friendly pairs");
        }
        else{
            System.out.print(num1 +" , "+num2+" are not friendly pairs");
        }
    }
}
