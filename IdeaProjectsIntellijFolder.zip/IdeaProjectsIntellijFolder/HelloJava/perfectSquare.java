

public class perfectSquare {
    public static void main(String args[]) {
        int num = 9;
        for (int i = 1; i <= Math.sqrt(num); i++) {
            if (i * i == num) {
                System.out.print(num + " is perfect square of " + i);
            }
        }
    }
/*
        System.out.println(isPerfectSqu(num));
    }
    //to check if num is perfect square or not

  static boolean isPerfectSqu(int x){

        int root = (int)Math.sqrt(x);

        return (root*root==x) ;
    }

     */
}
