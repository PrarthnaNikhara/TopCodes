public class nthTermInFibonacciSeries {
    public static void main(String[] args) {
        int n = 10;
        int a = 0;
        int b = 1;
        int nextTerm=0;
        for (int i = 2; i < n; i++) {
            nextTerm = a + b;
            a = b;
            b = nextTerm;
        }
        System.out.print(nextTerm);
    }
}
