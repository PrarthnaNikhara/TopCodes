public class primeFactors {
        public static void main(String[] args) {
            int num = 16;
//prime numbers start with 2
            boolean isPrimeFactor = true;
            for (int i = 2; i <= num; i++) {
                if (num % i == 0) {
                    for (int j = 2; j < i; j++) {
                        if (i % j == 0) {
                            isPrimeFactor = false;
                        }
                        if(isPrimeFactor){
                            System.out.println(i + " is factor of " + num);
                        }
                    }

                }
            }
        }
}
