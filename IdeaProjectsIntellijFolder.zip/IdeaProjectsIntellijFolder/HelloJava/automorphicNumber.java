public class automorphicNumber {
    public static void main(String args[]){
       // int num = 5;//5 -> 5^2 -> 25 -> 5 exits in last digits of its square ->automorphic number is 5
       int num = 376;//376^2 = 141376
        int number = num;
        int square = num*num;
        int len  = 0;
        while(num!=0){
            len++;
            num = num/10;
        }
        boolean isAutomorphic = true;
        for(int i = 1;i<=len;i++){
            if(number%10 != square%10){
                isAutomorphic = false;
            }
        }
        if(isAutomorphic){
            System.out.print(number + " is Automorphic number");
        }
        else{
            System.out.print(number + " is not Automorphic number");
        }
    }
}
