public class factorial {
    public static void main(String[] args){
        int num = 4;
        /*
        int fact = 1;
        for(int i=2; i<=num;i++){
            fact = fact*i;
        }
         */
        System.out.print(fact(num));
    }
    static int fact(int num){
        if(num == 0|| num==1){
            return 1;
        }
        return num*fact(num-1);
    }
}
