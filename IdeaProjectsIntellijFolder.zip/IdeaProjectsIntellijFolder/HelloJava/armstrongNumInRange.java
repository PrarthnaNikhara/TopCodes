public class armstrongNumInRange {

        public static void main(String[] args) {
            int initial = 1;
            int finale = 400;
            // int count=0;


            for (int num = initial; num <= finale; num++){
                int temp = num;
                int arm = 0;
                int len = order(num);
                while (temp != 0) {
                    int digit = temp%10;
                    arm = arm + (int) Math.pow(digit, len);
                    temp = temp/ 10;
                }
                if (num == arm) {
                    System.out.println(num+" is Armstrong");
                    //  count++;
                }
                /*
                else {
                    System.out.println(num+" is not Armstrong");
                    count++;
                }

                 */
            }
            // System.out.println(count +" total numbers checked!");
        }
        static int order(int x){
            int len = 0;
            while(x!=0){
                len++;
                x=x/10;
            }
            return len;
        }

    }


