public class factorsOfNumber {
    public static void main(String[] args){
        int num =  6;

        for(int i = 1; i <= (num);i++){     //i <= (int)Math.sqrt(num) this won't work as 3 won't print, sqrt of 6 is 2.something
            if(num%i == 0){
                System.out.println(i +" is factor of "+ num);
            }
        }

    }
}
